--[[
敗北画面 (そもそも敗北条件あるのか？)

概要：
・敗北した表示をする画面
・戻るボタンを押したらルーム選択画面に画面遷移する
]]

function setup()
	if not rootTbl then
		rootTbl = {}
	end
end

function execute(deltaT)
end

function leave()
end
