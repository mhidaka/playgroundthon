--[[
勝利画面

概要：
・勝利した表示をする画面
・戻るボタンを押したらルーム選択画面に画面遷移する
]]

function setup()
end

function execute(deltaT)
end

function leave()
end
